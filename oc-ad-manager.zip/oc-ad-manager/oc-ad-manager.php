<?php
/**
 * Plugin Name: Ad Manager by October Communications
 * Plugin URI: https://octobercomms.com
 * Description: Advertising rotation manager for Atlanta Design Festival. Supports MPU, Leaderboard, and Skyscraper formats with click and impression tracking, campaign scheduling, and flexible restriction controls.
 * Version: 1.0.0
 * Author: October Comms
 * Author URI: https://octobercomms.com
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: oc-ad-manager
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'OCAD_VERSION', '1.0.0' );
define( 'OCAD_PATH', plugin_dir_path( __FILE__ ) );
define( 'OCAD_URL', plugin_dir_url( __FILE__ ) );

define( 'OCAD_FORMATS', array(
	'mpu'         => array( 'label' => 'MPU',         'width' => 300, 'height' => 250 ),
	'leaderboard' => array( 'label' => 'Leaderboard', 'width' => 728, 'height' => 90  ),
	'skyscraper'  => array( 'label' => 'Skyscraper',  'width' => 160, 'height' => 600 ),
) );

require_once OCAD_PATH . 'includes/class-ocad-activator.php';
require_once OCAD_PATH . 'includes/class-ocad-campaign.php';
require_once OCAD_PATH . 'includes/class-ocad-tracker.php';
require_once OCAD_PATH . 'includes/class-ocad-partner.php';
require_once OCAD_PATH . 'includes/class-ocad-shortcodes.php';
require_once OCAD_PATH . 'includes/class-ocad-rest-api.php';

register_activation_hook( __FILE__, array( 'OCAD_Activator', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'OCAD_Activator', 'deactivate' ) );

if ( is_admin() ) {
	require_once OCAD_PATH . 'admin/class-ocad-admin.php';
	require_once OCAD_PATH . 'admin/class-ocad-settings.php';
	new OCAD_Admin();
	new OCAD_Settings();
}

$ocad_shortcodes = new OCAD_Shortcodes();
$ocad_shortcodes->register();

new OCAD_REST_API();

// Handle click-tracking redirect before any output.
add_action( 'template_redirect', 'ocad_handle_click_redirect' );
function ocad_handle_click_redirect() {
	if ( ! isset( $_GET['ocad_click'] ) ) {
		return;
	}

	$ad_id = absint( $_GET['ocad_click'] );
	if ( ! $ad_id ) {
		wp_safe_redirect( home_url( '/' ) );
		exit;
	}

	$ad = OCAD_Campaign::get_ad( $ad_id );
	if ( ! $ad ) {
		wp_safe_redirect( home_url( '/' ) );
		exit;
	}

	OCAD_Tracker::log_click( $ad->campaign_id, $ad_id );

	$campaign = OCAD_Campaign::get( $ad->campaign_id );
	$redirect  = $campaign ? $campaign->url : home_url( '/' );

	wp_redirect( esc_url_raw( $redirect ) );
	exit;
}
